from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import time


def ejecutar_prueba_interfaz():
    print("Iniciando prueba de interfaz con Selenium...")


    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service)

    try:

        driver.get("http://127.0.0.1:8000/")


        time.sleep(3)


        titulo_esperado = "Fridas"
        assert titulo_esperado in driver.title

        print(f"ÉXITO: Se logró conectar con la interfaz de '{driver.title}'")

    except Exception as e:
        print(f"ERROR: La prueba falló debido a: {e}")
    finally:

        driver.quit()


if __name__ == "__main__":
    ejecutar_prueba_interfaz()
